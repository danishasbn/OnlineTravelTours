<?php require('../common/dashboard-common/header.php'); ?>
<?php include('../Action/action-dashboard.php') ?>

<main class="col bg-faded py-3">
    <h2>Dashboard</h2>
    <p>This is your dashboard entry page</p>
</main>


<?php require('../common/dashboard-common/footer.php'); ?>
