<?php require('../../../../common/dashboard-common/header.php'); ?>
<?php require('../../../../Action/'); ?>

<main class="col bg-faded py-3">
    <h3 class="text-left"> >> Create new <small> <em> Day </em></small> <<</h3> 

</main>
<?php require('../../../../common/dashboard-common/footer.php'); ?>