

</div>
</div>
<!-- Footer -->
<div class="footer">
  <footer class="page-footer text-center text-muted">
    <div class="footer-copyright text-center py-3">
      <ul class=" list-inline">
        <li class="list-inline-item"><a href="#"><img class="social-icon" src="<?= 'http://localhost:'.$_SERVER['SERVER_PORT'].'/OnlineTravelTours/Asset/images/icons/social/fb-icon.png'; ?>" alt="social icon image" /></a></li>
        <li class="list-inline-item"><a href="#"><img class="social-icon" src="<?= 'http://localhost:'.$_SERVER['SERVER_PORT'].'/OnlineTravelTours/Asset/images/icons/social/insta-icon.png'; ?>" alt="social icon image" /></a></li>
        <li class="list-inline-item"><a href="#"><img class="social-icon" src="<?= 'http://localhost:'.$_SERVER['SERVER_PORT'].'/OnlineTravelTours/Asset/images/icons/social/twitter-icon.png'; ?>" alt="social icon image" /></a></li>
      </ul>
      <p class="text-center text-dark copyright"> &copy; Copyright 2019 <em> Paradise Chaser <em></p>
      </div>
    </footer>
  </div>
  <!-- /Footer -->

  <?php require( $_SERVER['DOCUMENT_ROOT'].'/OnlineTravelTours/common/foot.php'); ?>
</body>
</html>
