<?php
    @$user = $_SESSION['login-user'];
    if($user){
        if(isset($_POST['btn-checkout-carrental'])){
            // echo "check";
            $totalPrice = $_POST['txt-total-carrental'];

            $orderID    = $_POST['txt-carOrderID'];
            for($i=0; $i <  count($orderID); $i++){
                $getOrderId =  $orderID[$i];
                echo $getOrderId;
            }

        }else{
            echo "wrongg";
        }
    }else{
        echo "<meta http-equiv='refresh' content='0;url=../404.php'>";
    }
?>