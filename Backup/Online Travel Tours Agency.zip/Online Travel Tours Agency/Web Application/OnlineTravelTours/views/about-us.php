<?php require('../common/header.php');?>

<div class="container">
  <div class="row justify-content-center" >
    <h1 class="text-center trending"><img src="<?= $border; ?>" class="img-border"/> Our Story <img src="<?= $border; ?>" class="img-border"/></h1>
  </div>



</div>


<?php require('../common/footer.php');?>
