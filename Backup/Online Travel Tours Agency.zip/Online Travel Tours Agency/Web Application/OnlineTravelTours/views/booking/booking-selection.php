<?php require('../../common/header.php');?>

<div class="container">
  <div class="row justify-content-center">
    <div class="dropdown drp-selection">
        <button class="btn  btn-lg  btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Choose your payment option
        </button>
        <div class="dropdown-menu menu-selection" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="<?= $internetBanking; ?>"> >>> Internet Banking <<<</a>
            <a class="dropdown-item" href="<?= $payAtShowroom; ?>"> >>> Pay at Showroom <<<</a>
        </div>
    </div>
  </div>
  <div class="row justify-content-center">
    <img src="../../Asset/images/paymentoptions.png" class="payment-image img-fluid"/>
  </div>
</div>


<?php require('../../common/footer.php');?>
