<?php require('../../common/header.php');?>

<div class="container">
  <div class="row justify-content-center">
     <div class="pre-booking text-justify border">
    
        <div class="text-center pre-booking-img">
            <img src="../../Asset/images/logo/paradise-chaser-logo.png" class="img-fluid" />
        </div>
    <br>
    <h2 class="text-teal text-center"> Payment at Showroom</h2>
    <h4 class="text-teal">Pre-Order Booking</h4>
    <br>
    <a href="pre-booking-confirmation.pdf" class="btn-danger btn-lg" target="_blank" download>Download PDF</a>
    <script>
        jQuery(document).ready(function($) {
        $('a[href$=".pdf"]')
                .attr('download', '')
                .attr('target', '_blank'); 
        });
    </script>
    <br>
    <br>
  <h5>Below is your booking informations </h5>
    <br>
     <div class="text-center">
        <table class="table table-striped table-responsive table-bordered" style="width:100%">
          <thead>
            <th>Item</th>
            <th>Description</th>
            <th>Check In</th>
            <th>Check Out</th>
            <th>Total Price</th>
          </thead>
          <tbody>
            <tr>
              <td>HOTEL INDIGO SCOTTSDALE</td>
              <td>Room Type: Standard, Occupacy: 2 Adults, Meal Type: Half-Board</td>
              <td>20.05.2019</td>
              <td>22.05.2019</td>
              <td>Rs. 5800.00</td>
            </tr>
            <tr>
              <td>HOTEL INDIGO SCOTTSDALE</td>
              <td>Room Type: Standard, Occupacy: 1 Adult, Meal Type: Half-Board</td>
              <td>20.05.2019</td>
              <td>22.05.2019</td>
              <td>Rs. 2900.00</td>
            </tr>
          </tbody>
        </table>
     </div>
     <br>



     <p> Thank you for your Booking Request from ParadiseChaser. </p>
     <p> In order to receive your Booking Confirmation please finalize 100% of payment to one of our ParadiseChaser Ltd branch. within 24 hours of placing the order.</p>
     <p>Please note that this particular offer can sell out at any time, and if you do remain interested, we would request you to finalize your payment sooner rather than later.</p>
     <p class="text-danger font-weight-bold text-center">We accept payment by cash and card only. <br> * Cheques are not considered.</p>


     <p class="text-danger font-weight-bold text-center">VERY IMPORTANT: Please provide the 'Order Number' as a reference when finalizing payment in one of our office.</p>

     <p class="text-info text-center font-weight-bold" > Upon receipt of payment, you will receive the a printout of your Booking Confirmation . </p>
     <p class="text-info text-center font-weight-bold" > ** PLEASE NOTE THIS IS NOT A BOOKING CONFIRMATION AND PAYMENT IS STILL PENDING ** </p>
     </div>
  </div>

</div>


<?php require('../../common/footer.php');?>
